import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import { auditSchema, type Audit, type PageContent } from "@/lib/types";

const SYSTEM_PROMPT = `
You are a senior brand strategist performing a conservative, evidence-led
audit of one public homepage.

Evaluate only the supplied page content. Do not pretend to have reviewed
analytics, customers, competitors, technical accessibility, performance,
or pages that were not supplied.

Rules:
- Separate observed evidence from inference.
- Quote or closely paraphrase page language in evidence fields.
- Do not invent company facts.
- Prefer strategic issues over cosmetic preferences.
- Make recommendations specific enough to act on.
- Treat likely audience and conversion goal as hypotheses.
- Flag uncertainty and anything requiring human judgment.
- Keep each list concise and non-repetitive.

Scoring:
9–10 exceptional
7–8 strong
5–6 functional but inconsistent
3–4 significant weaknesses
1–2 fundamentally unclear or ineffective

The overall score is a strategic judgment, not a mechanical average.
`;

function buildPrompt(page: PageContent): string {
  return `
Audit this homepage.

URL
${page.url}

PAGE TITLE
${page.title || "Not found"}

META DESCRIPTION
${page.metaDescription || "Not found"}

HEADINGS
${page.headings.map((item) => `- ${item}`).join("\n") || "None found"}

LINK AND CTA TEXT
${page.links.map((item) => `- ${item}`).join("\n") || "None found"}

VISIBLE CONTENT
${page.visibleText}

Return a homepage-only audit with 3–5 prioritized recommendations.
`;
}

export async function auditHomepage(page: PageContent): Promise<Audit> {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error(
      "OPENAI_API_KEY is not configured. Add it to .env.local or your deployment environment.",
    );
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const response = await client.responses.parse({
    model: process.env.OPENAI_MODEL ?? "gpt-5-mini",
    input: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: buildPrompt(page) },
    ],
    text: {
      format: zodTextFormat(auditSchema, "homepage_audit"),
    },
  });

  if (!response.output_parsed) {
    throw new Error("The model did not return a usable structured audit.");
  }

  return auditSchema.parse(response.output_parsed);
}
