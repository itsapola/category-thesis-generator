import { z } from "zod";

export const auditCategorySchema = z.object({
  score: z.number().int().min(1).max(10),
  assessment: z.string(),
  strengths: z.array(z.string()).max(5),
  weaknesses: z.array(z.string()).max(5),
  evidence: z.array(z.string()).max(6),
  recommendation: z.string(),
  confidence: z.enum(["high", "medium", "low"]),
});

export const prioritySchema = z.object({
  title: z.string(),
  problem: z.string(),
  action: z.string(),
  expectedImpact: z.string(),
  impact: z.enum(["high", "medium", "low"]),
  effort: z.enum(["high", "medium", "low"]),
});

export const auditSchema = z.object({
  companySummary: z.string(),
  likelyAudience: z.string(),
  likelyConversionGoal: z.string(),
  executiveSummary: z.string(),
  overallScore: z.number().int().min(1).max(100),
  categories: z.object({
    homepageClarity: auditCategorySchema,
    positioning: auditCategorySchema,
    valueProposition: auditCategorySchema,
    differentiation: auditCategorySchema,
    audienceFit: auditCategorySchema,
    trust: auditCategorySchema,
    conversion: auditCategorySchema,
    contentQuality: auditCategorySchema,
  }),
  priorities: z.array(prioritySchema).min(3).max(5),
  assumptions: z.array(z.string()).max(8),
  limitations: z.array(z.string()).max(8),
  humanReviewRequired: z.array(z.string()).max(8),
});

export type Audit = z.infer<typeof auditSchema>;
export type AuditCategory = z.infer<typeof auditCategorySchema>;

export type PageContent = {
  url: string;
  title: string;
  metaDescription: string;
  headings: string[];
  links: string[];
  visibleText: string;
};
