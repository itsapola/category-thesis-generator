import * as cheerio from "cheerio";
import type { PageContent } from "@/lib/types";

const BLOCKED_HOSTS = new Set([
  "localhost",
  "127.0.0.1",
  "0.0.0.0",
  "::1",
]);

function normalizeUrl(input: string): URL {
  const trimmed = input.trim();
  if (!trimmed) throw new Error("Enter a website URL.");

  const withProtocol = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;

  let parsed: URL;
  try {
    parsed = new URL(withProtocol);
  } catch {
    throw new Error("Enter a valid public website URL.");
  }

  if (!["http:", "https:"].includes(parsed.protocol)) {
    throw new Error("Only HTTP and HTTPS URLs are supported.");
  }

  const hostname = parsed.hostname.toLowerCase();

  if (
    BLOCKED_HOSTS.has(hostname) ||
    hostname.endsWith(".local") ||
    hostname.startsWith("10.") ||
    hostname.startsWith("192.168.") ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(hostname)
  ) {
    throw new Error("Private or local network addresses are not allowed.");
  }

  return parsed;
}

function unique(values: string[], limit: number): string[] {
  return [...new Set(values.map((value) => value.trim()).filter(Boolean))].slice(
    0,
    limit,
  );
}

export async function scrapeHomepage(input: string): Promise<PageContent> {
  const url = normalizeUrl(input);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);

  try {
    const response = await fetch(url, {
      redirect: "follow",
      cache: "no-store",
      headers: {
        "User-Agent":
          process.env.AUDIT_USER_AGENT ??
          "BrandIntelligenceToolkit/1.0 (+https://github.com/)",
        Accept: "text/html,application/xhtml+xml",
      },
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`Website returned HTTP ${response.status}.`);
    }

    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.includes("text/html")) {
      throw new Error("The URL did not return an HTML webpage.");
    }

    const html = await response.text();
    if (html.length > 2_000_000) {
      throw new Error("The homepage is too large to analyze safely.");
    }

    const $ = cheerio.load(html);
    $("script, style, noscript, svg, iframe, template").remove();

    const title = $("title").first().text().trim();
    const metaDescription =
      $('meta[name="description"]').attr("content")?.trim() ?? "";

    const headings = unique(
      $("h1, h2, h3")
        .map((_, element) => $(element).text())
        .get(),
      50,
    );

    const links = unique(
      $("a")
        .map((_, element) => $(element).text())
        .get(),
      80,
    );

    const paragraphs = unique(
      $("p, li")
        .map((_, element) => $(element).text())
        .get(),
      160,
    );

    const visibleText = unique(
      [...headings, ...paragraphs, ...links],
      260,
    )
      .join("\n")
      .slice(0, 24_000);

    if (visibleText.length < 100) {
      throw new Error(
        "Very little visible text was found. The site may render content only in the browser or block automated access.",
      );
    }

    return {
      url: response.url || url.toString(),
      title,
      metaDescription,
      headings,
      links,
      visibleText,
    };
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("The website took too long to respond.");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}
