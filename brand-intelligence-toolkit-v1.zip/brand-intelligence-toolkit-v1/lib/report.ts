import type { Audit, AuditCategory } from "@/lib/types";

export const CATEGORY_LABELS = {
  homepageClarity: "Homepage Clarity",
  positioning: "Positioning",
  valueProposition: "Value Proposition",
  differentiation: "Differentiation",
  audienceFit: "Audience Fit",
  trust: "Trust & Credibility",
  conversion: "Conversion",
  contentQuality: "Content Quality",
} as const;

function bullets(items: string[]): string {
  return items.length ? items.map((item) => `- ${item}`).join("\n") : "- None";
}

function categorySection(label: string, category: AuditCategory): string {
  return `## ${label}

**Score:** ${category.score}/10  
**Confidence:** ${category.confidence}

### Assessment

${category.assessment}

### Strengths

${bullets(category.strengths)}

### Weaknesses

${bullets(category.weaknesses)}

### Evidence

${bullets(category.evidence)}

### Recommendation

${category.recommendation}
`;
}

export function generateMarkdown(audit: Audit, url: string): string {
  const scorecard = Object.entries(CATEGORY_LABELS)
    .map(
      ([key, label]) =>
        `| ${label} | ${audit.categories[key as keyof Audit["categories"]].score}/10 |`,
    )
    .join("\n");

  const sections = Object.entries(CATEGORY_LABELS)
    .map(([key, label]) =>
      categorySection(
        label,
        audit.categories[key as keyof Audit["categories"]],
      ),
    )
    .join("\n");

  const priorities = audit.priorities
    .map(
      (item, index) => `### ${index + 1}. ${item.title}

**Problem:** ${item.problem}

**Action:** ${item.action}

**Expected impact:** ${item.expectedImpact}

**Impact:** ${item.impact}  
**Effort:** ${item.effort}
`,
    )
    .join("\n");

  return `# Homepage Brand Intelligence Audit

**Website:** ${url}

> This report evaluates publicly visible homepage content only. It does not
> incorporate analytics, customer research, stakeholder interviews, technical
> accessibility testing, or a broader competitive review.

## Executive Summary

${audit.executiveSummary}

**Overall Score:** ${audit.overallScore}/100

## Inferred Business Context

**Company summary:** ${audit.companySummary}

**Likely primary audience:** ${audit.likelyAudience}

**Likely primary conversion goal:** ${audit.likelyConversionGoal}

## Scorecard

| Category | Score |
|---|---:|
${scorecard}

${sections}

# Priority Recommendations

${priorities}

# Assumptions

${bullets(audit.assumptions)}

# Limitations

${bullets(audit.limitations)}

# Human Review Required

${bullets(audit.humanReviewRequired)}

---

Generated with Brand Intelligence Toolkit. AI assisted with extraction,
structured evaluation, and drafting. Human review remains required for
strategic interpretation, brand judgment, and prioritization.
`;
}
