import { describe, expect, it } from "vitest";
import { generateMarkdown } from "@/lib/report";
import type { Audit } from "@/lib/types";

const category = {
  score: 7,
  assessment: "Clear but not fully differentiated.",
  strengths: ["Specific audience language"],
  weaknesses: ["Limited proof"],
  evidence: ["Visible claim"],
  recommendation: "Add quantified evidence.",
  confidence: "high" as const,
};

const audit: Audit = {
  companySummary: "Example company.",
  likelyAudience: "Marketing leaders.",
  likelyConversionGoal: "Book a call.",
  executiveSummary: "The page is clear but needs stronger proof.",
  overallScore: 70,
  categories: {
    homepageClarity: category,
    positioning: category,
    valueProposition: category,
    differentiation: category,
    audienceFit: category,
    trust: category,
    conversion: category,
    contentQuality: category,
  },
  priorities: [
    {
      title: "Strengthen proof",
      problem: "Claims lack evidence.",
      action: "Add metrics.",
      expectedImpact: "Greater trust.",
      impact: "high",
      effort: "low",
    },
    {
      title: "Clarify CTA",
      problem: "CTA is vague.",
      action: "Use a specific label.",
      expectedImpact: "Clearer next step.",
      impact: "high",
      effort: "low",
    },
    {
      title: "Differentiate",
      problem: "Message is generic.",
      action: "Name the distinctive method.",
      expectedImpact: "Stronger recall.",
      impact: "high",
      effort: "medium",
    },
  ],
  assumptions: ["Audience is inferred."],
  limitations: ["Homepage only."],
  humanReviewRequired: ["Validate positioning."],
};

describe("generateMarkdown", () => {
  it("renders the audit and score", () => {
    const markdown = generateMarkdown(audit, "https://example.com");
    expect(markdown).toContain("Overall Score:** 70/100");
    expect(markdown).toContain("Strengthen proof");
    expect(markdown).toContain("Homepage Clarity");
  });
});
