"use client";

import { FormEvent, useMemo, useState } from "react";
import type { Audit, PageContent } from "@/lib/types";
import { CATEGORY_LABELS, generateMarkdown } from "@/lib/report";

type Result = {
  audit: Audit;
  page: PageContent;
};

const confidenceClass = {
  high: "confidence high",
  medium: "confidence medium",
  low: "confidence low",
} as const;

function downloadMarkdown(result: Result) {
  const markdown = generateMarkdown(result.audit, result.page.url);
  const blob = new Blob([markdown], { type: "text/markdown;charset=utf-8" });
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = "homepage-brand-intelligence-audit.md";
  anchor.click();
  URL.revokeObjectURL(objectUrl);
}

export function AuditApp() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const categories = useMemo(() => {
    if (!result) return [];
    return Object.entries(CATEGORY_LABELS).map(([key, label]) => ({
      key,
      label,
      data: result.audit.categories[
        key as keyof typeof result.audit.categories
      ],
    }));
  }, [result]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setResult(null);
    setLoading(true);

    try {
      const response = await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });

      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload.error ?? "The audit could not be completed.");
      }

      setResult(payload as Result);
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "The audit could not be completed.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <section className="hero">
        <div className="eyebrow">Brand Intelligence Toolkit</div>
        <h1>See what your homepage is actually communicating.</h1>
        <p className="hero-copy">
          A structured, evidence-led audit of clarity, positioning,
          differentiation, trust, and conversion—built for strategic review,
          not generic AI commentary.
        </p>

        <form onSubmit={submit} className="audit-form">
          <label htmlFor="url">Public homepage URL</label>
          <div className="input-row">
            <input
              id="url"
              type="text"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              placeholder="ashleypola.com"
              autoComplete="url"
              disabled={loading}
            />
            <button type="submit" disabled={loading || !url.trim()}>
              {loading ? "Analyzing…" : "Run audit"}
            </button>
          </div>
          <p className="form-note">
            Homepage content only. Strategic conclusions require human review.
          </p>
        </form>

        {error && <div className="error">{error}</div>}
      </section>

      {!result && (
        <section className="preflight">
          <div>
            <span>01</span>
            <h2>Extract</h2>
            <p>Retrieve visible headings, claims, proof points, and CTAs.</p>
          </div>
          <div>
            <span>02</span>
            <h2>Evaluate</h2>
            <p>Score eight strategic categories against an explicit rubric.</p>
          </div>
          <div>
            <span>03</span>
            <h2>Prioritize</h2>
            <p>Turn findings into a focused, executive-ready action plan.</p>
          </div>
        </section>
      )}

      {loading && (
        <section className="loading-card">
          <div className="loader" />
          <div>
            <h2>Reading the homepage</h2>
            <p>
              Extracting evidence, testing the message, and building the audit.
            </p>
          </div>
        </section>
      )}

      {result && (
        <section className="results">
          <div className="results-header">
            <div>
              <div className="eyebrow">Audit complete</div>
              <h2>{result.page.url}</h2>
            </div>
            <button
              className="secondary-button"
              onClick={() => downloadMarkdown(result)}
            >
              Download Markdown
            </button>
          </div>

          <div className="summary-grid">
            <article className="score-card">
              <span>Overall score</span>
              <strong>{result.audit.overallScore}</strong>
              <small>/100</small>
            </article>
            <article className="executive-summary">
              <h3>Executive summary</h3>
              <p>{result.audit.executiveSummary}</p>
            </article>
          </div>

          <div className="context-grid">
            <article>
              <span>Company</span>
              <p>{result.audit.companySummary}</p>
            </article>
            <article>
              <span>Likely audience</span>
              <p>{result.audit.likelyAudience}</p>
            </article>
            <article>
              <span>Likely conversion goal</span>
              <p>{result.audit.likelyConversionGoal}</p>
            </article>
          </div>

          <div className="section-heading">
            <span>Scorecard</span>
            <h2>Where the message holds—and where it leaks.</h2>
          </div>

          <div className="score-grid">
            {categories.map(({ key, label, data }) => (
              <article className="category-card" key={key}>
                <div className="category-top">
                  <h3>{label}</h3>
                  <strong>{data.score}/10</strong>
                </div>
                <div className={confidenceClass[data.confidence]}>
                  {data.confidence} confidence
                </div>
                <p>{data.assessment}</p>
                <details>
                  <summary>View evidence and recommendation</summary>
                  <h4>Evidence</h4>
                  <ul>
                    {data.evidence.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <h4>Recommendation</h4>
                  <p>{data.recommendation}</p>
                </details>
              </article>
            ))}
          </div>

          <div className="section-heading">
            <span>Priority actions</span>
            <h2>Do these before polishing the furniture.</h2>
          </div>

          <div className="priority-list">
            {result.audit.priorities.map((priority, index) => (
              <article key={priority.title}>
                <div className="priority-number">
                  {String(index + 1).padStart(2, "0")}
                </div>
                <div>
                  <h3>{priority.title}</h3>
                  <p>{priority.problem}</p>
                  <h4>Recommended action</h4>
                  <p>{priority.action}</p>
                  <div className="tags">
                    <span>Impact: {priority.impact}</span>
                    <span>Effort: {priority.effort}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <details className="governance">
            <summary>Assumptions, limitations, and human review</summary>
            <div className="governance-grid">
              <div>
                <h3>Assumptions</h3>
                <ul>
                  {result.audit.assumptions.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3>Limitations</h3>
                <ul>
                  {result.audit.limitations.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h3>Human review</h3>
                <ul>
                  {result.audit.humanReviewRequired.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </details>
        </section>
      )}
    </main>
  );
}
