# Brand Intelligence Toolkit

A full-stack, AI-assisted homepage auditor for evaluating clarity, positioning,
value proposition, differentiation, audience fit, trust, conversion, and
content quality.

This repository operationalizes the website-audit methodology in
[Marketing OS](https://github.com/YOUR_USERNAME/marketing-os).

## What it does

1. Accepts a public homepage URL.
2. Retrieves and structures visible page content.
3. Evaluates eight strategic categories using a strict schema.
4. Surfaces evidence, confidence, assumptions, and limitations.
5. Produces prioritized recommendations.
6. Exports an executive-ready Markdown report.

## Architecture

```text
Browser
  ↓
Next.js interface
  ↓
POST /api/audit
  ├─ URL validation and SSRF guardrails
  ├─ Homepage retrieval and text extraction
  └─ OpenAI structured analysis
  ↓
Typed audit result
  ↓
Interactive scorecard + Markdown export
```

## Why Next.js only?

Version 1 deliberately uses a single deployable application rather than a
separate frontend and Python API. That keeps the system easy to run, review,
and deploy while still demonstrating frontend, backend, AI, validation,
testing, and product design.

A separate service becomes worthwhile only when crawling, queues, storage,
or long-running analysis require it.

## Local setup

```bash
npm install
cp .env.example .env.local
```

Add your API key to `.env.local`:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5-mini
```

Run:

```bash
npm run dev
```

Open `http://localhost:3000`.

## Codespaces setup

```bash
npm install
cp .env.example .env.local
nano .env.local
npm run dev
```

Use the forwarded port notification to open the application.

For a persistent Codespaces secret, add `OPENAI_API_KEY` under your GitHub
Codespaces secrets and restart the Codespace.

## Tests

```bash
npm test
```

## Deployment

Deploy the repository to Vercel and add these environment variables:

- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `AUDIT_USER_AGENT`

The audit endpoint uses the Node.js runtime and allows up to 60 seconds.

## Responsible-use boundaries

- Homepage content only.
- No analytics or customer data.
- No claim of technical accessibility testing.
- No claim of competitive research unless supplied separately.
- Inferred business context is labeled as inference.
- Strategic conclusions require human review.

## Roadmap

- Multi-page crawl with page selection
- Optional business context input
- Competitive comparison
- Saved audit history
- PDF export
- Regression tests for prompt changes
- Rate limiting and authentication
- Background jobs for larger audits

## License

MIT
