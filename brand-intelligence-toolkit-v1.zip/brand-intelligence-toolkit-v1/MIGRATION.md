# Replace the Existing Prototype

This package replaces the Python/Streamlit prototype with the Next.js version.

## In a GitHub Codespace

1. Upload the ZIP to the repository root.
2. In the terminal, verify you are in the repository:

```bash
pwd
```

3. Back up the current prototype:

```bash
mkdir -p prototype-backup
cp -R app prototype-backup/python-app 2>/dev/null || true
cp requirements.txt prototype-backup/requirements.txt 2>/dev/null || true
```

4. Unzip the package into a temporary folder:

```bash
unzip brand-intelligence-toolkit-v1.zip -d replacement
```

5. Copy the new project into the repository:

```bash
cp -R replacement/brand-intelligence-toolkit-v1/. .
```

6. Remove Python-only files from the project root after confirming the backup:

```bash
rm -f requirements.txt
```

7. Install and configure:

```bash
npm install
cp .env.example .env.local
```

8. Edit `.env.local` and add your API key:

```bash
nano .env.local
```

9. Run:

```bash
npm run dev
```

## Save to GitHub

```bash
git add .
git commit -m "Replace prototype with full-stack audit application"
git push
```
