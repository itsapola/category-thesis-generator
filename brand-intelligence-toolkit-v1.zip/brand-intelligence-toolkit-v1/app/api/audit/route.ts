import { NextResponse } from "next/server";
import { z } from "zod";
import { auditHomepage } from "@/lib/auditor";
import { scrapeHomepage } from "@/lib/scraper";

export const runtime = "nodejs";
export const maxDuration = 60;

const requestSchema = z.object({
  url: z.string().min(1).max(2_048),
});

export async function POST(request: Request) {
  try {
    const body = requestSchema.parse(await request.json());
    const page = await scrapeHomepage(body.url);
    const audit = await auditHomepage(page);

    return NextResponse.json({ page, audit });
  } catch (error) {
    console.error("Audit failed:", error);

    const message =
      error instanceof z.ZodError
        ? "Enter a valid website URL."
        : error instanceof Error
          ? error.message
          : "The audit could not be completed.";

    return NextResponse.json({ error: message }, { status: 400 });
  }
}
