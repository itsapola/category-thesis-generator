import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Brand Intelligence Toolkit",
  description:
    "Evaluate homepage clarity, positioning, differentiation, trust, and conversion.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
